#ifndef MAIN_H
#define MAIN_H

#include "src/pipeline.h"

#endif
